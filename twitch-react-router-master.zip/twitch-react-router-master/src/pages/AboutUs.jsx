const AboutUs = () => {
   return (
      <h4>About Us Page</h4>
   );
}

export default AboutUs;
