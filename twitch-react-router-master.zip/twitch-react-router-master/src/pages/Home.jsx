const Home = () => {
   return (
      <h4>Home Page</h4>
   );
}

export default Home;
