const NotFound = () => {
   return (
      <div>
         <h2>404</h2>
         <p>Not Found :(</p>
      </div>
   );
}

export default NotFound;
