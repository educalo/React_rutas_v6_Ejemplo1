# React Router v6 - Tutorial completo

En este repositorio te dejo el código base de una aplicación desarrollada React y [React Router](https://reactrouter.com/) en su versión 6.

El código que ves aquí es el mismo que escribo en [este video](https://youtu.be/qM8T4wXG2V4) en YouTube. Espero le puedas sacar un buen uso.

---

**Made with ❤️ : [Javi Herrera](https://javier-herrera.com)**

_Si te parece interesante este tipo de contenido, puedes agradecerme con un Follow en mis siguientes redes sociales. Lo estimaría un montón._

[<img src="./docs/icon-twitch.png" alt="icon twitch" width="26"/>](https://www.twitch.tv/thefullstackdevs)
[<img src="./docs/icon-instagram.png" alt="icon instagram" width="26"/>](https://www.youtube.com/c/thefullstackdevs)
[![icon spotify](./docs/icon-spotify.png)](https://open.spotify.com/show/3J2dLuBSfzt9VVnEF8q18a)
[![icon linkedin](./docs/icon-linkedin.png)](https://www.linkedin.com/in/javier-herrera-fullstack-developer/)
